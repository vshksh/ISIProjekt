
package com.mycompany.Security;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

/*
    Ta klasa ma inicjalizować Spring Security. W jakiś sposób Spring wykorzystuje coś takiego.
*/
public class SpringSecurityInitializer extends AbstractSecurityWebApplicationInitializer {
   //do nothing
}