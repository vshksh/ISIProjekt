/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany;

/**
 *
 * @author Przemek
 */
public class ZmianaStanu 
{
    private String nazwa="";
    private String co_zmienic="";
    private String nowa_wartosc="";

    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getCo_zmienic() {
        return co_zmienic;
    }

    public void setCo_zmienic(String co_zmienic) {
        this.co_zmienic = co_zmienic;
    }

    public String getNowa_wartosc() {
        return nowa_wartosc;
    }

    public void setNowa_wartosc(String nowa_wartosc) {
        this.nowa_wartosc = nowa_wartosc;
    }
    
}
