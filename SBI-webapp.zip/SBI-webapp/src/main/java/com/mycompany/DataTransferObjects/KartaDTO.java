package com.mycompany.DataTransferObjects;


public class KartaDTO {
    
    String nazwa;
    String PIN;
    
    public String getNazwa() {
        return nazwa;
    }

    public void setNazwa(String nazwa) {
        this.nazwa = nazwa;
    }

    public String getPIN() {
        return PIN;
    }

    public void setPIN(String PIN) {
        this.PIN = PIN;
    }

    
    
}
