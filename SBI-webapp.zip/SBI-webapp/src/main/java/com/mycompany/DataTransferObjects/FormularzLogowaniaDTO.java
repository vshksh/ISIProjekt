package com.mycompany.DataTransferObjects;



/**
 *
 * @author Jeremiasz
 */
public class FormularzLogowaniaDTO {

    private String email;
    

    private String haslo;


        public String getHaslo() {
		return haslo;
	}

	public void setHasło(String nazwisko) {
		this.haslo = haslo;
	}
      
        
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
    


}
